import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
	    Scanner SC = new Scanner(System.in);
	    int a,c=0;
	    a = SC.nextInt();
	    int n[] = new int[a];
	    for(int i=0; i<a; i++)
	    {
	        n[i] = SC.nextInt();
	    }
	    for(int i=0; i<a; i++)
	    if(n[i]>c)
	    c = n[i];
	    {
	        System.out.println(c);
	    }
	}
}
